# azure_paying_me
trying to secure different payments on iOS with Azure as back-end

/ Azure is easy to set up. Anyone knows a good application server? Let me know. I do not want to pay too much and use Tomcat.
/ How to sequence the payment pages at the best levels
/ How to save users payments information better....
/ Focus on paypal and square at the beginning .... not a fan of visa
